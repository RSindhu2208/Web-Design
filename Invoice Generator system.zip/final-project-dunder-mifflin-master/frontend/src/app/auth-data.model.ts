export interface AuthData
{
  email:String;
  password:String;
}
//interface of authentication data
