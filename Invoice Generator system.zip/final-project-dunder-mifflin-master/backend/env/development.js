export const devConfig = {
    port: 3000,
    database: 'invoice-builder',
    secret: 'AHSDEUIYEIUER',
    frontendURL: 'http://localhost:4200',
    ethereal: {
      username: 'beau.cruickshank82@ethereal.email',
      password: 'xapng6WFup3BnKRfMM',
      host: 'smtp.ethereal.email',
      port: 587,
    },
  };
  